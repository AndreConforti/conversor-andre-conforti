def metros_para_centimetros(metros):
    """Converte metros para centímetros."""
    return metros * 100

def centimetros_para_metros(centimetros):
    """Converte centímetros para metros."""
    return centimetros / 100
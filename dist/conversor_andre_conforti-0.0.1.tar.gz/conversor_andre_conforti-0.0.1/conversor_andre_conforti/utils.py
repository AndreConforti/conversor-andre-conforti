def formatar_unidade(valor, unidade):
    """Formata um valor com a unidade."""
    return f"{valor:.2f} {unidade}"